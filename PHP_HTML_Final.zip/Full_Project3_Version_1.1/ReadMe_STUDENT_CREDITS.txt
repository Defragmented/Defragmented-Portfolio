////////////////////////////////////////////////////////////////////////////////
Version 0.1:

>Added Auto_Increment to ID in DB Script
>Added a check to ID to make sure the user can't go below 0000
>Changed 'index' to a php file
>Changed 'userid' to 'int' and made it 'Auto Increment' in database
>Achieved input and partial output
>Changed 'index.html' to 'index.php'
>Moved main php input to 'index.php'
>Separated 'connect' and 'output' from main file
>Adjusted html fields to be 'required' as to prevent page from submitting early
>Made minor adjustments to JS file
>Made major adjusments to php input, php won't run until all fields have values
{Need to fix outputs}

////////////////////////////////////////////////////////////////////////////////
Version 0.2:

>Added two new functions to 'formScript.js' to handle form submissions
>Edited PHP to call success and unsuccess functions
>Removed onclick from form submit button
>Changed default select option to have no value
>Data validation reworked
{Need to fix outputs}

///////////////////////////////////////////////////////////////////////////////////////////////////
Version 0.3

>Added output script w/ support for it
>Changed div 'dateOrRangeDiv' to a form {will need fixed CSS}
>Editted output file to use 'GET' method instead of 'POST', this is to prevent them from colliding
>Minor visual changes to PHP and HTML codes, this is only within the code not on the page
>Fixed cancel button for 'dateOrRangeDiv' div
>Added new function to display a date range error
>Added visuals for PHP and Js functions in the 'formScript'
{Add a check for if the user only puts the end date}
{Add check to prevent user from entering date range out of order}

///////////////////////////////////////////////////////////////////////////////////////////////////
Version 0.4

>Added outputPage.php
>Added Images folder
>Added output.js
>Added output.css

>Open output.php for some basic info on how it works built into the placeholder info

>TODO - make outputPage.php open when the user requests data

>TODO - write the onLoad for outputPage.php to pull appropriate data for the page

>TODO - make the number of reps per body part display on cursor hover for the body parts display
	[Optional, possible feature creep, less work than gradient system]

///////////////////////////////////////////////////////////////////////////////////////////////////////
Version 0.5

>Fixed MySQL connection error code
>Major adjustments to output
>Changed 'output.php' to 'getOuputVariables.php'
>Added dynamic date heading to 'outputPage.php'
>Added action to 'index.php' to send you to the output page
>Separated 'input.php'
>Added validation for incorrectly input date ranges
>Added validation for form input submissions
>Condensed 'getOuputVariables.php' and moved most of the working code to 'outputPage.php'
>Added output array of all queried data to 'output.js'

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Version 0.6

>Add function to hover over data to show used muscles per workout
>Add prettiness
>Changed data output to make each segment into unordered lists
>Added new functions to aid in DOM elements
>Added DOM elements for date confirmation
>Added functions to 'form script' to aid with date confirmation
>Changed output to replace start page instead of opening to a separate tab
>Added ability to disable button when confirmation message is on screen
>Added error checking to prevent user from changing dates or anything on screen until confirmation has been clicked yes or no
>Added DB script to files

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Version 0.6.1

>Fixed form not resetting when the user returns to the index page

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Version 0.7

>Added new column for totals of exercises

>Writes all data to a multidimensional array in outputPage.php

>Added onhover functions to the ul elements in outputPage.php

/////////////////////////////////////////////////////////////////////////////////
Version 0.8

>Fixed irritating issue of going back one page and having an eternal alert box

/////////////////////////////////////////////////////////////////////////////////
Version 0.9

>Added validation to date form

/////////////////////////////////////////////////////////////////////////////////
Verion 0.10

>Changed DOM display of exercise name from <span> to <label>

>Implemented onhover part lightup 

/////////////////////////////////////////////////////////////////////////////////
Version 1.0

>Implemented summary numbers in outputPage.php

>Implemented back button on outputPage.php

>Implemented some light coloring

>Refined css spacing of elements in all areas

/////////////////////////////////////////////////////////////////////////////////
Version 1.1 RELEASE

>Changed css styling for several elements, enabled dark mode

>Organized files into folders

CREDITS:

Jaden
	>.js coding, majority of output.js and formscript.js

	>Coding and art for the body part display box on the output page
		>Hand-drawn
		>Scripting, HTML, and CSS all self-contained in div
	
	>HTML formatting for most elements

	>ALL .css formatting and visual design

	>Overall project planning

	>Adapted output php for .css targeting and .js script targeting

Dakota
	>Main .php coding in implementation of database communication

	>Database architect

	>DOM coding & implementation

	>PHP to javascript communication function implementation for skeletal data

Nathan
	>PHP consulting

	>PHP code for retreiving data and communicating to page

	>DOM concept

	>input validation