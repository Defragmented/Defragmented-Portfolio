
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise Logging Service</title>
    <link rel="stylesheet" href="styles/normalize.css">
    <link rel="stylesheet" href="styles/index.css">
    <script src="scripts/formScript.js"></script>
</head>
<div id="wrapper"></div>
<body>
    <h1>Exercise Tracking</h1>
    <fieldset class="logField"><legend>Exercise Logging:</legend>
        <div class="logField">
            <input type="button" id="menuNewSession" value="Enter New Session" onclick="entryFormOpen()">
            <input type="button" id="menuSubmitData" value="Submit Data" onclick="entryFormSubmit()">
        </div>
    </fieldset>
    <fieldset class="infoField"><legend>Analyze Previous Exercise Data</legend>
        <div id="dateOrRangeDiv">
            <form action="outputPage.php" method="GET" if="outputDateQueryForm">
                Analyze by date or date range: <br>
                <label>Start Date:</label> <input type="date" id="firstDateInput" name="firstDateInput" 
                min="2000-01-01" max="2100-01-01" required> 
                
                <br>
                <label>End Date:</label> <input type="date" id="secondDateInput" name="secondDateInput" 
                min="2000-01-01" max="2100-01-01">

                <em><small>leave blank if analyzing one day</small></em>
                <br>
                &emsp;&emsp;<button type="button" name="Enter" id="dateOrRangeEnter" onclick="DateValidation()">Enter</button>
                &emsp; <input type="reset" value="Clear" id="dateOrRangeClear">

                <div style="margin-top: 16px;" id="confirmationDiv">

                </div>
            </form>
        </div>

        <!--
            <br><input type="button" id="infoFieldDisplayTest" value="Run Test" onclick="testDebugFunction()"> 
        -->

    </fieldset>

    <dialog id="dialogSessionInput" class="dialogBox"><form method="POST" >

        <!--Date-->
        <h3>Input Session Info:</h3>
        &emsp; <label>Date:</label> <input type="date" id="sessionDateInput" name="sessionDateInput"
        min="2000-01-01" max="2100-01-01" required> 
        <br><br>

        <!--Exercise-->
        &emsp; <label for="exercisesInput">Exercise:</label> 
        <select id="exercisesInput" name="exercisesInput" required>
            <option disabled selected hidden>Choose One</option>
            <option value="Squats">Squats</option>
            <option value="Lunges">Lunges</option>
            <option value="Crunches">Crunches</option>
            <option value="Push-Ups">Push-ups</option>
            <option value="Presses">Presses</option>
            <option value="Pull-Ups">Pull-ups</option>
        </select>
        <!--
            /////////////////////////////////////////////////////////////////////////////////////////
            //TO ADD MORE ITEMS, ADD THEM IN output.js LINE 93 AND index.php LINE 60
            /////////////////////////////////////////////////////////////////////////////////////////
        -->
        <!--Sets-->
        <br><br>
        &emsp; <label># of sets:</label> <input type="number" id="setsInput" name="setsInput" min="1" max="255" required
        onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))">
        <br><br>

        <!--Reps-->
        &emsp; <label># of reps:</label> <input type="number" id="repsInput" name="repsInput" min="1" max="255" required
        onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))">
        <br><br>

        <!--Submit-->
        &emsp;&emsp;<input type="submit" id="menuSubmitData2" name="Submit_Data" 
        value="Submit Data">
        <br>

        <!--Cancel-->
        &emsp;&emsp;<input type="reset" id="menuCancel" 
        value="Cancel" onclick="cancelButton()">
        

    </form></dialog>

</body>
</html>

<?php echo "<br>"; include('scripts/connect.php'); ?>

<?php include('scripts/input.php'); ?>

<?php include('scripts/getOuputVariables.php'); ?>