<?php echo "<br>"; include('scripts/connect.php'); ?>

<?php include('scripts/input.php'); ?>

<?php include('scripts/getOuputVariables.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise Data</title>
    <script src="scripts/output.js"></script>
    <link rel="stylesheet" href="styles/normalize.css">
    <link rel="stylesheet" href="styles/output.css">
</head>
<body onload="initializeOutput()">
    <div class="header">
        Data from: 
        <?php 
            if($exerciseDate != "" AND $secondExerciseDate == "")
            {
                echo $exerciseDate;
            }
            else if($exerciseDate != "" AND $secondExerciseDate != "")
            {
                echo $exerciseDate . " through " . $secondExerciseDate;
            }
            else
                echo "No date given";
        ?>
    </div>
    
    <div id="displayTableDiv" class="displayTableDiv">
            <?php
                #Array for output to Js
                $OutputPageArray = array();

                #Runs when only the first variable has a date
                //////////////////////////////////////////////////////////////////////////
                if($exerciseDate != "" AND $secondExerciseDate == "")
                {  
                    #SQL for data extraction
                    $mysql = "SELECT * FROM users WHERE ExerciseDate = '$exerciseDate' ORDER BY ExerciseDate ASC";
    
                    #Query to obtain data
                    $query = mysqli_query($connectToDB, $mysql);
    
                    #Testing output
                    if ($query->num_rows > 0) 
                    {
                        #Output data of each row
                        while($row = $query->fetch_assoc()) 
                        {
                            echo 
                                "<ul onmouseover = 'ulHoverEvent(this)' onmouseout = 'ulHoverLeave(this)'>• Date: " . $row["ExerciseDate"] . "<br>" 
                              . "• Exercise: " . "<label>" . $row["ExerciseName"] . "</label>" . "<br>"
                              . "• Sets: " . $row["ExerciseSets"] . "<br>" 
                              . "• Reps: " . $row['ExerciseReps'] . "<br><br></ul>";

                            $arr_value1 = $row["ExerciseName"];
                            $arr_value2 = $row["ExerciseSets"];
                            $arr_value3 = $row['ExerciseReps'];

                            $arr_data1 = $arr_value1;
                            $arr_data2 = $arr_value2;
                            $arr_data3 = $arr_value3;
                            
                            array_push(
                                $OutputPageArray, 
                                $arr_value1,
                                $arr_value2,
                                $arr_value3
                            );

                        }
                    } 
                    else 
                    {
                        #Output for when no data is returned
                        echo "<ul> No workouts were recorded on this day. </ul>";
                    }
                }
                //////////////////////////////////////////////////////////////////////////

                #Runs when both variables have a date
                //////////////////////////////////////////////////////////////////////////
                else if($exerciseDate != "" AND $secondExerciseDate != "")
                {
                    #SQL for data extraction
                    $mysql = "SELECT * FROM users WHERE ExerciseDate >= '$exerciseDate' AND ExerciseDate <= '$secondExerciseDate'
                    ORDER BY ExerciseDate ASC";

                    #Query to obtain data
                    $query = mysqli_query($connectToDB, $mysql);

                    #Testing output
                    if ($query->num_rows > 0) 
                    {
                        #Output data of each row
                        while($row = $query->fetch_assoc()) 
                        {
                            echo 
                                "<ul onmouseover = 'ulHoverEvent(this)' onmouseout = 'ulHoverLeave(this)'>• Date: " . $row["ExerciseDate"] . "<br>" 
                              . "• Exercise: " . "<label>" . $row["ExerciseName"] . "</label>" . "<br>"
                              . "• Sets: " . $row["ExerciseSets"] . "<br>" 
                              . "• Reps: " . $row['ExerciseReps'] . "<br><br></ul>";

                            $arr_value1 = $row["ExerciseName"];
                            $arr_value2 = $row["ExerciseSets"];
                            $arr_value3 = $row['ExerciseReps'];

                            $arr_data1 = $arr_value1;
                            $arr_data2 = $arr_value2;
                            $arr_data3 = $arr_value3;
                              
                            array_push(
                                $OutputPageArray, 
                                $arr_value1,
                                $arr_value2,
                                $arr_value3
                            );
                        }
                    } 
                    else 
                    {
                        #Output for when no data is returned
                        echo "<ul> No workouts were recorded on this day. </ul>";
                    }
                }
                //////////////////////////////////////////////////////////////////////////

                #Disconnection from MySQL
                $closeDB = mysqli_close($connectToDB);
            ?>
    </div>

    <div id="displayTotalCountsDiv" class="displayTotalCountsDiv">
        <label>Total:</label>
            <div id="generateSummaryDiv">

            </div>
    </div>

    <div id="displayImageDiv" class="displayImageDiv">
            <label id="frontViewLabel" class="imagePosition1">Front</label>
            <label id="backViewLabel" class="imagePosition2">Back</label>
            <img id="viewFrontBase" class="imagePosition1" src="images/humanBlack.png">
            <img id="viewBackBase" class="imagePosition2" src="images/humanBlack.png">
            <img id="chest" class="bodyPart imagePosition1 chest" src="images/chest.png">
            <img id="abs" class="bodyPart imagePosition1 abs" src="images/abs.png">
            <img id="armsLower" class="bodyPart imagePosition1 armsLower" src="images/armsLower.png">
            <img id="armsUpper" class="bodyPart imagePosition1 armsUpper" src="images/armsUpper.png">
            <img id="shoulders" class="bodyPart imagePosition1 shoulders" src="images/shoulders.png">
            <img id="legsLower" class="bodyPart imagePosition1 legsLower" src="images/legsLower.png">
            <img id="legsUpper" class="bodyPart imagePosition1 legsUpper" src="images/legsUpper.png">
            <img id="back" class="bodyPart imagePosition2 back" src="images/chest.png">
            <img id="back2" class="bodyPart imagePosition2 back" src="images/abs.png">

            <div id="textPane" class="textPane">
                <label>Muscle Groups: </label>
                <ul>
                    <li id="chestLabel" class="partLabel chest">Chest</li>
                    <li id="absLabel" class="partLabel abs">Abdominals</li>
                    <li id="shouldersLabel" class="partLabel shoulders">Shoulders</li>
                    <li id="upperArmsLabel" class="partLabel armsUpper">Upper Arms</li>
                    <li id="lowerArmsLabel" class="partLabel armsLower">Lower Arms</li>
                    <li id="upperLegsLabel" class="partLabel legsUpper">Thighs</li>
                    <li id="lowerLegsLabel" class="partLabel legsLower">Calves</li>
                    <li id="backLabel" class="partLabel back">Back</li>
                </ul>
            </div>
            <style>
                .displayImageDiv{
                    position: relative;  /* This block sets the div as the parent and specifies the origin point */
                    top: 0;
                    left: 0;
                    border: solid black 2px;
                    width: 550px;
                    height: 430px;
                }
                .textPane{ /*Make text pane flush with image window*/
                    position: absolute;
                    top: -2px;
                    left: 400px;
                    border: solid black 2px;
                    width: 148px;
                    height: 430px;

                    background-color: #2f3136;
                }
                .textPane > label{
                    display: block;
                    text-align: center;
                    margin: auto;
                    padding: 20px;
                }
                .textPane > ul {
                    padding-top: 0;
                    margin-top: 0;
                }
                .textPane > ul > li {
                    color: gray;
                }
                .imagePosition1{ /*All 'absolute' positioned elements are positions in relation to the div now */
                    position: absolute;
                    top: 20px;
                    left: 0;
                }
                .imagePosition2{ /*things marked with position2 are rendered 200px to the right, on the back face model */
                    position: absolute;
                    top: 20px;
                    left: 200px;
                }
                .bodyPart{
                    visibility: hidden;
                }
                label.imagePosition1{
                    width: 50px;
                    text-align: center;
                    position: absolute;
                    top: 0;
                    left: 75px;
                }
                label.imagePosition2{
                    width: 50px;
                    text-align: center;
                    position: absolute;
                    top: 0;
                    left: 275px;
                }
            </style>
            <script>
                var chest = document.getElementById("chest").style;
                var abs = document.getElementById("abs").style;
                var shoulders = document.getElementById("shoulders").style;
                var armsUpper = document.getElementById("armsUpper").style;
                var armsLower = document.getElementById("armsLower").style;
                var legsUpper = document.getElementById("legsUpper").style;
                var legsLower = document.getElementById("legsLower").style;
                var back = document.getElementById("back").style;
                var back2 = document.getElementById("back2").style;

                function wipeDisplay() //func to wipe all highlights for refreshing
                {
                    var bodyparts = document.getElementsByClassName("bodyPart");
                    for (let iterator = 0; iterator < bodyparts.length; iterator++)
                    {
                        bodyparts[iterator].style.visibility = "hidden";
                    }
                    var bodyPartLabels = document.getElementsByClassName("partLabel");
                    for (let iterator = 0; iterator < bodyPartLabels.length; iterator++)
                    {
                        bodyPartLabels[iterator].style.color = "gray";
                        bodyPartLabels[iterator].style.fontWeight = "normal";
                    }
                }
                
                //takes an array of strings as an argument, if a part appears at least once
                //display the part as image and text
                //List of valid strings to push to array function
                    // "chest"
                    // "abs"
                    // "shoulders"
                    // "armsUpper"
                    // "armsLower"
                    // "legsUpper"
                    // "legsLower"
                    // "back"
                function displayBodyParts(arrayToDisplay) 
                {
                    var bodyparts = document.getElementsByClassName("bodyPart"); //get list of image elements
                    for (let iterator = 0; iterator < bodyparts.length; iterator++)
                    {
                        if (arrayToDisplay.includes(bodyparts[iterator].classList.item(2)))
                        {
                            bodyparts[iterator].style.visibility = "visible";
                        }
                    }

                    var bodyPartLabels = document.getElementsByClassName("partLabel");
                    for (let iterator = 0; iterator < bodyPartLabels.length; iterator++)
                    {
                        if (arrayToDisplay.includes(bodyPartLabels[iterator].classList.item(1)))
                        {
                            bodyPartLabels[iterator].style.color = "lightgray";
                            bodyPartLabels[iterator].style.fontWeight = "bold";
                        }
                    }
                }
            </script>

            <input type="button" onclick="goBack()" value = "Go Back" id="backButton">
    </div>
    <!--/////////////////////////////////////////////////////////////////////////////////////////
    //TO CAUSE BODY PARTS TO DISPLAY GRAPHICALLY
    displayBodyParts(arrayToDisplay) 
                //SEND ARRAY OF BOOLS TO THIS FUNCTION
                //List of valid strings to push to array function, in order
                    // "chest"
                    // "abs"
                    // "shoulders"
                    // "armsUpper"
                    // "armsLower"
                    // "legsUpper"
                    // "legsLower"
                    // "back"        
                    //send array of bools to function in onload to display them  
    /////////////////////////////////////////////////////////////////////////////////////////-->
    
    <!--Hidden, will show if cookies are set in Insepct Element-->

    <script>
        const x = <?php echo json_encode($OutputPageArray); ?>;
        //console.log(x);
    </script>
                
</body>
</html>