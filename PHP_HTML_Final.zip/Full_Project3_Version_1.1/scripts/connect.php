<?php
    #Connect to MySQL
    $connectToDB = mysqli_connect('localhost', 'root', '', 'userWorkoutHistory');
    if(!$connectToDB)
    {
        die('Could not connect: ' . mysql_error());
    }
?>