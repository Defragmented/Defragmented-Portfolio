//Functions specifically for PHP
//////////////////////////////////////////////////////////////////////////

function SuccessfulSubmission()
{
    alert("Workout has been submitted.");
}

function UnsuccessfulSubmission()
{
    alert("Your entry failed, please try again.");
}

function InvalidDateRange()
{
    alert("Invalid date range.");
}

//////////////////////////////////////////////////////////////////////////

//Functions specfically for Javascript
function testFunction()
{
    console.log("test");
}


function entryFormOpen()
{
    openButton = document.getElementById("menuNewSession");
    closeButton = document.getElementById("menuSubmitData");
    dialogBox = document.getElementById("dialogSessionInput");


    openButton.style.visibility = "hidden";
    closeButton.style.visibility = "visible";
    dialogBox.show();

    dateInput = document.getElementById("sessionDateInput");
    dateInput.valueAsDate = new Date(); //set default to current date

}

function DataValidation() 
{       

    // var canEnd = true;
    // closeButton = document.getElementById("menuSubmitData");
    // openButton = document.getElementById("menuNewSession");
    // dialogBox = document.getElementById("dialogSessionInput");

    //let dateInput = document.getElementById("sessionDateInput");
    //let exerciseInput = document.getElementById("exercisesInput");
    //let setsInput = document.getElementById("setsInput");
    //let repsInput = document.getElementById("repsInput");

    // console.log(dateInput.value);
    // console.log(exerciseInput.value);
    // console.log(setsInput.value);
    // console.log(repsInput.value);

    // if (setsInput.value == "")
    // {
    //     alert("Please fill in your sets.");
    //     // canEnd = false;
    // }
    // if (repsInput.value == "")
    // {
    //     alert("Please fil in your reps.");
    //     // canEnd = false;
    // }

    // if (canEnd == true)
    // {
    //     openButton.style.visibility = "visible";
    //     closeButton.style.visibility = "hidden";
    //     dialogBox.close();
    //     console.log(dateInput.value);

    //     var outputArray = [dateInput.value, exerciseInput.value, setsInput.value, repsInput.value];
    //     writeToDatabase(outputArray);

    //     clearExerciseInputs();
    // }
    // else
    // {
    //     alert("Please fill all inputs")
    // }
}

function cancelButton()
{
    clearExerciseInputs();
    dialogBox = document.getElementById("dialogSessionInput");
    dialogBox.close();
    
    openButton.style.visibility = "visible";
    closeButton.style.visibility = "hidden";
}

function clearExerciseInputs()
{
    dateInput = document.getElementById("sessionDateInput");
    exerciseInput = document.getElementById("exercisesInput");
    setsInput = document.getElementById("setsInput");
    repsInput = document.getElementById("repsInput");

    dateInput.valueAsDate = new Date(); //set default to current date
    exerciseInput.value = "default";
    setsInput.value = "";
    repsInput.value = "";
}

function DateConfirmation()
{ 
    //Creates Elements to append to specialized div
    const yesButton = document.createElement("INPUT");
    const noButton = document.createElement("INPUT");
    const paragraph = document.createElement("P");
    const paragraphText = document.createTextNode("Are you sure you want to submit?");
    const firstDate = document.getElementById("firstDateInput");
    const secondDate = document.getElementById("secondDateInput");

    paragraph.appendChild(paragraphText);

    paragraph.setAttribute("id", "confirmationText");

    yesButton.setAttribute("type", "submit");
    yesButton.setAttribute("name", "Yes");
    yesButton.setAttribute("id", "dateSubmit");
    yesButton.setAttribute("value", "Yes");

    noButton.setAttribute("type", "reset");
    noButton.setAttribute("name", "No");
    noButton.setAttribute("id", "dateCancel");
    noButton.setAttribute("onclick", "removeElements()");
    noButton.setAttribute("value", "No");

    firstDate.setAttribute("readonly", true);
    secondDate.setAttribute("readonly", true);

    document.getElementById("confirmationDiv").appendChild(paragraph);
    document.getElementById("confirmationDiv").appendChild(yesButton);
    document.getElementById("confirmationDiv").appendChild(noButton); 

    document.getElementById("dateOrRangeEnter").disabled = true;
    document.getElementById("dateOrRangeClear").disabled = true;
    document.getElementById("menuNewSession").disabled = true;

}

function DateValidation()
{
    const Date1 = document.getElementById("firstDateInput").value;
    const Date2 = document.getElementById("secondDateInput").value;

    if(Date1 != "" && Date2 == "")
        DateConfirmation();
    else if(Date1 == "" && Date2 != "")
        alert("Invalid date range.");
    else if(Date1 < Date2)
        DateConfirmation();
    else if(Date1 > Date2)
        alert("Invalid date range.");
    else if(Date1 == Date2)
        alert("Invalid date range.");
    else if(Date1 == "" && Date2 == "")
        alert("Fields cannot be left blank.");
    
}

function removeElements()
{
    if (document.querySelector("#dateSubmit"))  
    {
        //if datesubmit exists, all this stuff exists, so it can be removed 
        //this if block makes sure the elements exist
        document.getElementById("dateSubmit").remove();
        document.getElementById("dateCancel").remove();
        document.getElementById("confirmationText").remove();
        document.getElementById("dateOrRangeEnter").disabled = false;
        document.getElementById("dateOrRangeClear").disabled = false;
        document.getElementById("menuNewSession").disabled = false;
        document.getElementById("firstDateInput").removeAttribute("readonly");
        document.getElementById("secondDateInput").removeAttribute("readonly");
    }
    else;
    {

    }
}

window.onunload = function() {
    removeElements();
    document.getElementById("firstDateInput").value = "";
    document.getElementById("secondDateInput").value = "";

}




// function dateOrRangeEnter()
// {
//     dateOutput1 = document.getElementById("firstDateInput").value;
//     dateOutput2 = document.getElementById("secondDateInput").value;
//     databaseArray = getDevToolArray(); //when integrated, replace getDevToolArray();

//     //send dateOutput1 (and dateOutput2 if applicable) to database
//     //as a request, and return multidimensional array to dataBaseArray
//     console.log(dateOutput1);

//     if (dateOutput2 == "") //Single day mode
//     {
//         console.log("DATE MODE");

//         singleDateDatabaseQuery(dateOutput1);

//         //byDateOpen();
//     }
//     else //multiple day mode
//     {
//         if (dateOutput2 >= dateOutput1) 
//         {
//             //THIS BLOCK RUNS WHEN THE DATES ARE IN THE RIGHT ORDER
//             console.log("DATE RANGE MODE");
            
//             dateRangeDatabaseQuery([dateOutput1, dateOutput2]);


            
//         }
//         else
//         {
//             //THIS BLOCK RUNS IF THE RANGE IS INVALID, END DATE BEFORE START DATE
//             console.log("WRONG ORDER");
//             alert("Invalid date range.");

//         }
//     }
// }

function singleDateDatabaseQuery(date)
{
    console.log("singleDateQueryRunning");
    console.log(date);

}

function dateRangeDatabaseQuery(dateArray)
{
    console.log("dateRangeQueryRunning");
    console.log(dateArray);

}

function byDateOpen() //dialog open/close handler
{
    dateDialog = document.getElementById("dialogDisplayByDate");
    dateDialog.show();
}

function closeByDateDialog() //dialog open/close handler
{
    dateDialog = document.getElementById("dialogDisplayByDate");
    dateDialog.close();
}

function dateOrRangeClear() //text clearer
{
    dateOutput1 = document.getElementById("firstDateInput");
    dateOutput2 = document.getElementById("secondDateInput");

    dateOutput1.value = "";
    dateOutput2.value = "";
}