<?php
    if($_SERVER['REQUEST_METHOD'] == "GET")
    {
        if(isset($_GET['Yes']))
        {
            #Date Variable
            $exerciseDate = $_GET['firstDateInput'];
            $secondExerciseDate = $_GET['secondDateInput'];

        }
    }
?>