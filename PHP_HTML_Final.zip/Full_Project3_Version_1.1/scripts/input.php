<?php
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        if(isset($_POST['Submit_Data']) AND isset($_POST['sessionDateInput'])
        AND isset($_POST['exercisesInput']) AND isset($_POST['setsInput']) AND isset($_POST['repsInput']))
        {
            //////////////////////////////////////////////////////////////////////////

            #Grab variables from HTML
            $exerciseDate = $_POST['sessionDateInput'];
            $exerciseName = $_POST['exercisesInput'];
            $exerciseSets = $_POST['setsInput'];
            $exerciseReps = $_POST['repsInput'];

            #Stores variables to transfer to our Database
            $mysql = "INSERT INTO Users (ExerciseDate, ExerciseName, ExerciseSets, ExerciseReps)
            VALUES ('$exerciseDate', '$exerciseName', '$exerciseSets', '$exerciseReps')";

            #Query to insert to our Database
            $mysqlQuery = mysqli_query($connectToDB, $mysql);

            if($mysqlQuery === true)
                echo '<script id="removeMe" type="text/javascript">SuccessfulSubmission();</script>'
                    .'<script type="text/javascript">window.location.href=window.location.href;</script>';
            else
                echo '<script type="text/javascript">UnsuccessfulSubmission();</script>'
                    .'<script type="text/javascript">window.location.href=window.location.href;</script>';

            //////////////////////////////////////////////////////////////////////////
        }
        else
        {
            echo '<script type="text/javascript">UnsuccessfulSubmission();</script>'
                .'<script type="text/javascript">window.location.href=window.location.href;</script>';
        }
    }
?>