class Exercise
{
    constructor(ExerciseName)
    {
        this.name = ExerciseName;
        this.Chest = "false";
        this.Shoulders = "false";
        this.ArmsUpper = "false";
        this.ArmsLower = "false";
        this.Abdominals = "false";
        this.LegsUpper = "false";
        this.LegsLower = "false";
        this.Back = "false";
    }
}

function initializeOutput()
{

 
    console.log("output.js loaded");

    wipeDisplay(); //wipe display

    //console.log(x.length);

    var exerciseDataArray = [];
    var sessionCount = 0;

    for (var i = 0; i < x.length; i += 3)
    {
        exerciseDataArray[sessionCount] = [x[i], x[i+1], x[i+2]];
        sessionCount += 1;
    }

    //console.table(exerciseDataArray);

//STUFF FOR SUMMARY BLOCK

makeSummary(exerciseDataArray);

 

}

function makeSummary(inputArray)
{
    var outputArray = [];

    //RUNS ONCE PER EXERCISE SESSION

    for (var i = 0; i < inputArray.length; i++)
    {

        var session = inputArray[i];
        var nameString = "";
        var total = 0;

        nameString = session[0];
        total = session[1] * session[2];

        var isNewExercise = true;
        var exerciseToModifyIndex;

        for (var j = 0; j < outputArray.length; j++) //Check every element in current outputArray
        {
            //If a match is found, we are not entering a new exercise
            //and we need to record which one we are writing to
            if (outputArray[j][1] == nameString) 
            {
                isNewExercise = false;
                exerciseToModifyIndex = j;
            }
        }

        //Decide if make a new entry, or modify old entry

        if (isNewExercise == true)
        {
            outputArray.push([total, nameString]);
        }
        else
        {
            outputArray[exerciseToModifyIndex][0] = outputArray[exerciseToModifyIndex][0] + total;
        }

    }

    outputArray.sort(function (a, b) {return b[0] - a[0]}); //sort array by number instead of alphabetically

    console.table(inputArray);
    console.table(outputArray);

    //set the div

    const summaryDiv = document.querySelector('#displayTotalCountsDiv');

    //Make one UL

    const ul = document.createElement('ul');

    //make one li element per item

    for (var i = 0; i < outputArray.length; i++)
    {
        const li = document.createElement('li');
        li.textContent = `${outputArray[i][1]}: ${outputArray[i][0]}`;
        ul.appendChild(li);
    }

    summaryDiv.appendChild(ul);
}

function ulHoverEvent(ul)
{
    var span = ul.getElementsByTagName('label')[0];
    ul.style.backgroundColor = 'black';
    var exerciseName = span.innerHTML;

    console.log(exerciseName);

    displayStringArray = getDisplayStringArray(exerciseName);
    displayBodyParts(displayStringArray);
}

function getDisplayStringArray(exerciseName)
{
////////////////////////////////////////////////////////////////////////////////////////

// <option value="Squats">Squats</option>
// <option value="Lunges">Lunges</option>
// <option value="Crunches">Crunches</option>
// <option value="Push-Ups">Push-ups</option>
// <option value="Presses">Presses</option>
// <option value="Pull-Ups">Pull-ups</option>

////////////////////////////////////////////////////////////////////////////////////////
//TO CAUSE BODY PARTS TO DISPLAY GRAPHICALLY
//displayBodyParts(arrayToDisplay) 
            //SEND ARRAY OF BOOLS TO THIS FUNCTION
            //List of valid strings to push to array function, in order
                // "chest"
                // "abs"
                // "shoulders"
                // "armsUpper"
                // "armsLower"
                // "legsUpper"
                // "legsLower"
                // "back"        
                //send array of bools to function in onload to display them  
                    //EXAMPLE
                // displayBodyParts(["chest", "shoulders", "armsUpper"]);
/////////////////////////////////////////////////////////////////////////////////////////
    //TO ADD MORE ITEMS, ADD THEM IN output.js LINE 93 AND index.php LINE 60
/////////////////////////////////////////////////////////////////////////////////////////

    var outputArray = [];

    if (exerciseName == "Squats")
    {
        outputArray.push("legsUpper");
        outputArray.push("legsLower");
        outputArray.push("abdominals");
    }

    if (exerciseName == "Lunges")
    {
        outputArray.push("legsUpper");
        outputArray.push("legsLower");
        outputArray.push("abs");
    }

    if (exerciseName == "Crunches")
    {
        outputArray.push("abs");
    }

    if (exerciseName == "Push-Ups")
    {
        outputArray.push("armsUpper");
        outputArray.push("armsLower");
        outputArray.push("chest");
        outputArray.push("shoulders");
    }

    if (exerciseName == "Pull-Ups")
    {
        outputArray.push("armsUpper");
        outputArray.push("back");
        outputArray.push("shoulders");
        outputArray.push("abs");
        outputArray.push("armsLower");
    }

    if (exerciseName == "Presses")
    {
        outputArray.push("armsUpper");
        outputArray.push("back");
        outputArray.push("shoulders");
        outputArray.push("chest");
    }




    console.log (outputArray);
    return outputArray;
}

function ulHoverLeave(ul)
{
    console.log("left area");
    ul.style.backgroundColor = '#292b2f';

    wipeDisplay();
}

function goBack()
{
    window.history.back();
}