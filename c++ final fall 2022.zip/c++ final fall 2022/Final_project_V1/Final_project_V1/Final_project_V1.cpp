// Final_project_V1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include "cards-classes.h"
using namespace std;




int main()
{
	bool exitGame = false;
	vector<Card> library = cardinit();





	//main game loop
	while (exitGame == false) {
		string input;
		cout << "Enter command: \n";
		getline(cin, input);
		if (input == "helloworld")
		{
			cout << "testphrase" << endl;
		}
		if (input == "end")
		{
			exitGame = true;
		}
		if (input == "teststrike")
		{
			cout << library[2].damage << endl;
		}
	}
	system("pause");
	return 0;
}