#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;


//Stats used by all combat entities
class Stats {
public:
	int vulnerable = 0;
	int weak = 0;
	int strength = 0;
	int dexterity = 0;
	int health = 0;
	int maxHealth = 0;
};
class Card : public Stats {
public:
	string name = "";
	int damage = 0;
	int block = 0;
	int cost = 0;
	bool exhaust = false;
	int ammo = 0;
};
class Enemy : public Stats {
public:
	string name;
};

class Player : public Stats {
public:
	//stats player only
	int energy;
	int energyPerTurn;
};

vector<Card> cardinit() {
	vector<Card> library;

	Card strike;
	strike.damage = 6;
	strike.cost = 1;
	library.push_back(strike);

	Card defend;
	defend.damage = 5;
	defend.cost = 1;
	library.push_back(defend);

	Card flashbang;
	flashbang.damage = 3;
	flashbang.weak = 1;
	flashbang.cost = 0;
	library.push_back(flashbang);




	return library;
}
